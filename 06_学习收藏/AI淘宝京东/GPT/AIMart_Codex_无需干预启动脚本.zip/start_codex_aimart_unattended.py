#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AIMart Codex 无需干预启动脚本

作用：
1. 在指定工作目录中检查 AIMart 的规格文件。
2. 自动拼接并保存 Codex 执行 Prompt。
3. 调用 Codex CLI 的非交互模式：codex exec。
4. 使用 workspace-write 沙箱和 never approval，避免中途频繁打断。
5. 要求 Codex 自主生成代码、写测试、运行测试、修复错误、生成报告。
6. 在 Codex 返回后，本脚本可选择本地运行 pytest；若失败，会把失败日志再次交给 Codex 自动修复。
7. 最终把运行日志、Prompt、Codex 最终输出、测试结果保存到 codex_runs/ 目录。

前提：
- 本机已安装 Codex CLI。
- Codex CLI 已登录/已配置认证。
- 你的工作目录中已经放好 AIMart 规格文件。
- 推荐先在独立仓库或新目录中运行，避免覆盖其他项目。

用法：
    python start_codex_aimart_unattended.py --workdir /path/to/your/aimart_project

常用：
    python start_codex_aimart_unattended.py --workdir . --max-repair-rounds 3

只启动 Codex，不额外本地跑 pytest：
    python start_codex_aimart_unattended.py --workdir . --skip-local-pytest

注意：
- 本脚本不会接入真实支付。
- 本脚本会明确要求 Codex 禁止真实支付、高风险自动调用、算力金融衍生品、真实跨境数据交易。
"""

from __future__ import annotations

import argparse
import datetime as _dt
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Iterable, List, Tuple


REQUIRED_OR_RECOMMENDED_FILES = [
    "00_AIMart_Codex_总控指令.md",
    "01_AIMart_Whitepaper.md",
    "02_AIMart_Boundary.md",
    "03_AIMart_Constraints.md",
    "04_AIMart_Capability.md",
    "05_AIMart_Config.md",
    "06_AIMart_Audit.md",
    "07_AIMart_Exec_01_Skeleton.md",
    "08_AIMart_Exec_02_RulesEngine.md",
    "09_AIMart_Exec_03_AgentCardValidator.md",
    "10_AIMart_Exec_04_AuditLog.md",
    "11_AIMart_Exec_05_CoreAPI.md",
    "99_AIMart_文件索引与验收清单.md",
    "AIMart_MVP_Codex_完整合并总文件_v2.md",
]

OPTIONAL_FILES = [
    "CODING_INSTRUCTIONS.md",
    "AIMart_Codex_使用说明与总控指令.md",
]

EXPECTED_OUTPUTS = [
    "README.md",
    "requirements.txt",
    "pytest.ini",
    ".env.example",
    "app/main.py",
    "config",
    "schemas",
    "agent_cards",
    "tests",
    "docs/ASSUMPTIONS.md",
    "docs/IMPLEMENTATION_REPORT.md",
    "docs/SELF_REVIEW.md",
    "docs/API_USAGE.md",
]


def now_stamp() -> str:
    return _dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def read_text_if_exists(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="replace")


def check_files(workdir: Path) -> Tuple[List[str], List[str]]:
    present = []
    missing = []
    for name in REQUIRED_OR_RECOMMENDED_FILES:
        if (workdir / name).exists():
            present.append(name)
        else:
            missing.append(name)
    return present, missing


def ensure_codex_available() -> None:
    if shutil.which("codex") is None:
        print("错误：没有找到 codex 命令。请先安装并登录 Codex CLI。", file=sys.stderr)
        print("确认方式：在终端运行 codex --help", file=sys.stderr)
        sys.exit(2)


def build_master_prompt(workdir: Path, missing: Iterable[str]) -> str:
    optional_present = [name for name in OPTIONAL_FILES if (workdir / name).exists()]
    optional_text = "\n\n".join(
        f"# 附加说明文件：{name}\n\n{read_text_if_exists(workdir / name)}"
        for name in optional_present
    )

    missing_list = "\n".join(f"- {m}" for m in missing) if missing else "无"

    return f"""你是 AIMart 项目的首席后端工程师、架构实现助手、测试负责人和代码审查者。

工作目录已经设置为：
{workdir}

请先读取工作目录内所有 AIMart 规格文件，尤其是：

{chr(10).join(f"{i+1}. {name}" for i, name in enumerate(REQUIRED_OR_RECOMMENDED_FILES))}

缺失文件清单：
{missing_list}

如果某些文件缺失但不涉及真实支付、生产部署、高风险能力自动调用、真实跨境数据、算力金融产品或真实客户敏感数据，请自行做合理默认假设，并写入 docs/ASSUMPTIONS.md，不要停下来反复提问。

你的目标：
生成 AIMart MVP 后端系统，并且必须自主编写代码、自主写测试、自主运行测试、自主修复问题、自主生成自审报告。

推荐技术栈：
- Python 3.11+
- FastAPI
- Pydantic
- SQLAlchemy 或 SQLModel
- 开发环境 SQLite，结构兼容 PostgreSQL
- PyYAML
- jsonschema
- pytest
- httpx / TestClient
- NDJSON append-only 审计日志
- Mock Payment / Mock Escrow

第一阶段必须实现：
1. 项目目录结构；
2. 配置加载；
3. AgentCard Schema 校验；
4. AgentCard 语义校验；
5. 边界和约束规则加载；
6. 权限检查器；
7. 规则引擎；
8. Agent 成熟度检查；
9. 风险检查；
10. 预算检查；
11. 数据政策检查；
12. 审计日志模块；
13. Capability 搜索与详情 API；
14. Requirement 创建 API；
15. Quote 请求 API；
16. Order 草案 API；
17. Mock Payment / Mock Escrow；
18. Milestone 基础流程；
19. Feedback 提交 API；
20. 按 trace_id 查询审计事件；
21. pytest 测试；
22. README.md；
23. docs/ASSUMPTIONS.md；
24. docs/IMPLEMENTATION_REPORT.md；
25. docs/SELF_REVIEW.md；
26. docs/API_USAGE.md。

第一阶段禁止实现：
1. 真实支付；
2. 真实 x402/ACP/AP2 付款；
3. AI Agent 自动大额购买；
4. 高风险能力自动调用；
5. 算力期货或算力金融衍生品；
6. 真实跨境数据交易；
7. 生产环境部署；
8. 复杂 UI 商城；
9. 完整 MCP Server；
10. A2A 多 Agent 自动协作网络；
11. 使用真实客户敏感数据；
12. 绕过审计日志的任何交易或 Agent 行为；
13. 把密钥写进代码；
14. 关闭关键验收测试。

你必须按阶段执行：
Phase 0：读取规格文件，输出理解摘要；
Phase 1：生成项目骨架；
Phase 2：生成配置、Schema、示例 AgentCard；
Phase 3：实现数据模型；
Phase 4：实现配置加载器、规则引擎、权限检查器；
Phase 5：实现审计日志模块；
Phase 6：实现核心 API；
Phase 7：实现 Mock Payment / Escrow / Milestone；
Phase 8：实现测试；
Phase 9：运行测试并修复；
Phase 10：生成 SELF_REVIEW.md；
Phase 11：生成 IMPLEMENTATION_REPORT.md。

必须通过的最低验收测试：
1. L0/L1 Agent 只能搜索和读取，不能报价、下单、调用。
2. L2 Agent 可以发起报价请求。
3. L4 Agent 只能在预算内调用低风险能力。
4. L4 Agent 不能调用高风险能力。
5. 超预算必须返回 BUDGET_EXCEEDED。
6. Agent 成熟度不满足时必须返回 AGENT_MATURITY_REQUIRED。
7. AgentCard 缺少 input_schema 或 output_schema 不能上架。
8. 非 active 能力不能被调用。
9. 高风险能力必须 required_human_approval=true。
10. dev 环境真实支付必须关闭。
11. 项目制订单必须走 Milestone。
12. 争议订单不能结算。
13. 所有 Agent 行为必须写 audit event。
14. 所有资金动作必须写 audit event。
15. 审计日志必须 append-only。
16. 可以按 trace_id 查询事件链。
17. 敏感字段不得明文写入日志。
18. 算力金融衍生品交易必须被阻止。
19. 跨境数据交易默认必须被阻止或要求明确审批。
20. pytest 必须通过。

最终必须生成：
- README.md
- requirements.txt
- pytest.ini
- .env.example
- app/
- config/
- schemas/
- agent_cards/
- tests/
- docs/ASSUMPTIONS.md
- docs/IMPLEMENTATION_REPORT.md
- docs/SELF_REVIEW.md
- docs/API_USAGE.md

每次不确定时：
- 如果不是高风险事项，请做合理默认假设并继续；
- 把假设写入 docs/ASSUMPTIONS.md；
- 不要频繁询问用户。

请现在开始实施。你可以先输出理解摘要和实施计划，但不要等待用户确认，继续按阶段创建代码、测试、运行测试、修复问题并生成最终报告。

{optional_text}
"""


def run_command(
    cmd: List[str],
    cwd: Path,
    stdout_file: Path,
    stderr_file: Path,
    timeout: int | None = None,
) -> int:
    print(f"\n[RUN] {' '.join(cmd[:6])}{' ...' if len(cmd) > 6 else ''}")
    with stdout_file.open("w", encoding="utf-8") as out, stderr_file.open("w", encoding="utf-8") as err:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd),
            stdout=out,
            stderr=err,
            text=True,
            timeout=timeout,
        )
        return proc.returncode


def run_codex_exec(workdir: Path, prompt: str, run_dir: Path, label: str, model: str | None) -> int:
    output_last = run_dir / f"{label}_codex_final_message.md"
    stdout_log = run_dir / f"{label}_stdout.log"
    stderr_log = run_dir / f"{label}_stderr.log"

    cmd = [
        "codex",
        "exec",
        "--cd",
        str(workdir),
        "--sandbox",
        "workspace-write",
        "--ask-for-approval",
        "never",
        "--output-last-message",
        str(output_last),
    ]

    # 如果你想指定模型，可传 --model，例如：
    # python start_codex_aimart_unattended.py --model gpt-5.2-codex
    if model:
        cmd.extend(["--model", model])

    cmd.append(prompt)

    return run_command(cmd, cwd=workdir, stdout_file=stdout_log, stderr_file=stderr_log)


def run_pytest(workdir: Path, run_dir: Path, label: str, timeout: int) -> int:
    stdout_log = run_dir / f"{label}_pytest_stdout.log"
    stderr_log = run_dir / f"{label}_pytest_stderr.log"
    return run_command(
        [sys.executable, "-m", "pytest", "-q"],
        cwd=workdir,
        stdout_file=stdout_log,
        stderr_file=stderr_log,
        timeout=timeout,
    )


def collect_pytest_failure(run_dir: Path, label: str) -> str:
    out = read_text_if_exists(run_dir / f"{label}_pytest_stdout.log")
    err = read_text_if_exists(run_dir / f"{label}_pytest_stderr.log")
    return f"# pytest stdout\n\n{out}\n\n# pytest stderr\n\n{err}"


def expected_outputs_status(workdir: Path) -> str:
    lines = []
    for rel in EXPECTED_OUTPUTS:
        p = workdir / rel
        lines.append(f"- [{'x' if p.exists() else ' '}] {rel}")
    return "\n".join(lines)


def build_repair_prompt(reason: str, previous_status: str) -> str:
    return f"""AIMart MVP 自动修复任务。

你刚才的实现还没有完全通过验收。

问题摘要：
{reason}

当前关键输出文件状态：
{previous_status}

请继续在当前工作目录中修复问题。要求：
1. 不要重建整个项目，优先增量修复。
2. 不要删除关键测试来规避失败。
3. 不要启用真实支付。
4. 不要允许高风险能力自动调用。
5. 不要实现算力金融衍生品。
6. 修复后再次运行 pytest。
7. 更新 docs/IMPLEMENTATION_REPORT.md 和 docs/SELF_REVIEW.md。
8. 如果需要默认假设，写入 docs/ASSUMPTIONS.md。
9. 最终确保 pytest 通过或在报告中明确剩余失败原因。
"""


def main() -> int:
    parser = argparse.ArgumentParser(description="AIMart Codex 无需干预启动脚本")
    parser.add_argument("--workdir", default=".", help="AIMart 工作目录，默认当前目录")
    parser.add_argument("--max-repair-rounds", type=int, default=3, help="pytest 失败后的 Codex 自动修复轮数")
    parser.add_argument("--skip-local-pytest", action="store_true", help="跳过脚本本地运行 pytest，只让 Codex 自己运行")
    parser.add_argument("--pytest-timeout", type=int, default=600, help="本地 pytest 超时时间，秒")
    parser.add_argument("--model", default=None, help="可选：指定 Codex 模型，例如 gpt-5.2-codex")
    args = parser.parse_args()

    workdir = Path(args.workdir).expanduser().resolve()
    if not workdir.exists():
        print(f"错误：工作目录不存在：{workdir}", file=sys.stderr)
        return 2

    ensure_codex_available()

    present, missing = check_files(workdir)
    print("=== AIMart Codex 无需干预启动 ===")
    print(f"工作目录：{workdir}")
    print(f"已找到规格文件：{len(present)}")
    if missing:
        print("缺失文件：")
        for m in missing:
            print(f"  - {m}")
        print("将继续执行，并要求 Codex 在 ASSUMPTIONS.md 中记录合理假设。")

    run_dir = workdir / "codex_runs" / now_stamp()
    run_dir.mkdir(parents=True, exist_ok=True)

    prompt = build_master_prompt(workdir, missing)
    prompt_path = run_dir / "codex_unattended_prompt.md"
    prompt_path.write_text(prompt, encoding="utf-8")
    print(f"Prompt 已保存：{prompt_path}")

    # 第一轮执行
    rc = run_codex_exec(workdir=workdir, prompt=prompt, run_dir=run_dir, label="round_0", model=args.model)
    print(f"Codex round_0 退出码：{rc}")

    if args.skip_local_pytest:
        print("已跳过本地 pytest。请查看 Codex 输出和 docs/IMPLEMENTATION_REPORT.md。")
        print(f"运行日志目录：{run_dir}")
        return rc

    # 本地 pytest + 自动修复循环
    for round_no in range(args.max_repair_rounds + 1):
        label = f"round_{round_no}"
        pytest_rc = run_pytest(workdir=workdir, run_dir=run_dir, label=label, timeout=args.pytest_timeout)
        print(f"pytest {label} 退出码：{pytest_rc}")

        outputs_status = expected_outputs_status(workdir)
        (run_dir / f"{label}_expected_outputs_status.md").write_text(outputs_status, encoding="utf-8")

        if pytest_rc == 0:
            print("\n✅ pytest 已通过。")
            print(f"运行日志目录：{run_dir}")
            print("请查看 docs/SELF_REVIEW.md 和 docs/IMPLEMENTATION_REPORT.md。")
            return 0

        if round_no >= args.max_repair_rounds:
            print("\n⚠️ pytest 仍未通过，已达到最大修复轮数。")
            print(f"运行日志目录：{run_dir}")
            return pytest_rc

        failure = collect_pytest_failure(run_dir, label)
        failure_path = run_dir / f"{label}_pytest_failure_for_repair.md"
        failure_path.write_text(failure, encoding="utf-8")

        repair_prompt = build_repair_prompt(
            reason=f"本地 pytest 失败，失败日志已保存到：{failure_path}",
            previous_status=outputs_status,
        )
        repair_prompt_path = run_dir / f"round_{round_no + 1}_repair_prompt.md"
        repair_prompt_path.write_text(repair_prompt, encoding="utf-8")

        rc = run_codex_exec(
            workdir=workdir,
            prompt=repair_prompt,
            run_dir=run_dir,
            label=f"round_{round_no + 1}_repair",
            model=args.model,
        )
        print(f"Codex 修复 round_{round_no + 1} 退出码：{rc}")

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
