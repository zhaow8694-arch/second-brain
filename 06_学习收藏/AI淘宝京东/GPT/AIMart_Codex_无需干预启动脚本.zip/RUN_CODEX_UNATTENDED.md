# AIMart Codex 无需干预启动脚本使用说明

## 1. 文件

本包包含：

```text
start_codex_aimart_unattended.py
```

把它放到 AIMart 工作目录中，或者任意目录运行时用 `--workdir` 指向 AIMart 工作目录。

---

## 2. 前提条件

你需要已经安装并登录 Codex CLI。

确认方式：

```bash
codex --help
```

---

## 3. 最推荐的运行方式

在 AIMart 工作目录运行：

```bash
python start_codex_aimart_unattended.py --workdir .
```

它会：

```text
1. 检查 14 个 AIMart 规格文件。
2. 自动生成 Codex 执行 Prompt。
3. 调用 codex exec 非交互模式。
4. 要求 Codex 自主生成 AIMart MVP 后端。
5. 本地运行 pytest。
6. 如果 pytest 失败，自动把失败日志交给 Codex 修复。
7. 最多修复 3 轮。
8. 保存所有日志到 codex_runs/时间戳/。
```

---

## 4. 指定工作目录

```bash
python start_codex_aimart_unattended.py --workdir /你的/工作目录
```

---

## 5. 增加自动修复轮数

```bash
python start_codex_aimart_unattended.py --workdir . --max-repair-rounds 5
```

---

## 6. 不额外本地跑 pytest

如果你只想让 Codex 自己跑测试：

```bash
python start_codex_aimart_unattended.py --workdir . --skip-local-pytest
```

---

## 7. 指定模型

```bash
python start_codex_aimart_unattended.py --workdir . --model gpt-5.2-codex
```

模型名称以你本地 Codex CLI 支持的模型为准。

---

## 8. 重要说明

脚本会使用：

```text
codex exec
--sandbox workspace-write
--ask-for-approval never
```

这意味着 Codex 会在工作目录内非交互执行，并尽量不向你请求确认。

请务必在独立仓库或新目录运行，避免覆盖其他项目。
