from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Numeric,
    String,
    UniqueConstraint,
    CheckConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class BudgetPool(Base):
    __tablename__ = "budget_pools"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    owner_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("participants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    currency: Mapped[str] = mapped_column(
        Enum("CNY", "USD", "USDC", name="currency_enum"), nullable=False
    )
    balance: Mapped[float] = mapped_column(
        Numeric(18, 4), nullable=False, default=0
    )
    frozen_amount: Mapped[float] = mapped_column(
        Numeric(18, 4), nullable=False, default=0
    )
    total_cap: Mapped[float | None] = mapped_column(
        Numeric(18, 4), nullable=True
    )
    single_transaction_max: Mapped[float] = mapped_column(
        Numeric(18, 4), nullable=False, default=500
    )
    daily_max: Mapped[float] = mapped_column(
        Numeric(18, 4), nullable=False, default=2000
    )
    weekly_max: Mapped[float] = mapped_column(
        Numeric(18, 4), nullable=False, default=10000
    )
    monthly_max: Mapped[float] = mapped_column(
        Numeric(18, 4), nullable=False, default=30000
    )
    auto_recharge: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )
    recharge_threshold: Mapped[float | None] = mapped_column(
        Numeric(18, 4), nullable=True
    )
    recharge_amount: Mapped[float | None] = mapped_column(
        Numeric(18, 4), nullable=True
    )
    status: Mapped[str] = mapped_column(
        Enum("active", "suspended", "closed", name="pool_status_enum"),
        nullable=False,
        default="active",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    __table_args__ = (
        CheckConstraint("balance >= 0", name="ck_budget_pool_balance_nonneg"),
        CheckConstraint("frozen_amount >= 0", name="ck_budget_pool_frozen_nonneg"),
    )

    # relationships
    allocations: Mapped[list[AgentBudgetAllocation]] = relationship(
        "AgentBudgetAllocation", back_populates="pool", lazy="selectin"
    )
    transactions: Mapped[list[PaymentTransaction]] = relationship(
        "PaymentTransaction", back_populates="pool", lazy="noload"
    )
    snapshots: Mapped[list[DailyBudgetSnapshot]] = relationship(
        "DailyBudgetSnapshot", back_populates="pool", lazy="noload"
    )

    @property
    def available_balance(self) -> float:
        return float(self.balance) - float(self.frozen_amount)


class AgentBudgetAllocation(Base):
    __tablename__ = "agent_budget_allocations"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    pool_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("budget_pools.id", ondelete="CASCADE"),
        nullable=False,
    )
    agent_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("participants.id", ondelete="CASCADE"),
        nullable=False,
    )
    daily_max: Mapped[float] = mapped_column(
        Numeric(18, 4), nullable=False, default=500
    )
    per_call_max: Mapped[float] = mapped_column(
        Numeric(18, 4), nullable=False, default=1
    )
    daily_spent: Mapped[float] = mapped_column(
        Numeric(18, 4), nullable=False, default=0
    )
    daily_spent_date: Mapped[date | None] = mapped_column(
        Date, nullable=True
    )
    spending_authority_level: Mapped[str] = mapped_column(
        Enum("L0", "L1", "L2", "L3", name="authority_level_enum"),
        nullable=False,
        default="L0",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    __table_args__ = (
        UniqueConstraint("agent_id", "pool_id", name="uq_agent_pool"),
    )

    pool: Mapped[BudgetPool] = relationship(
        "BudgetPool", back_populates="allocations"
    )


class PaymentTransaction(Base):
    __tablename__ = "payment_transactions"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    pool_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("budget_pools.id", ondelete="CASCADE"),
        nullable=False,
    )
    order_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False
    )
    agent_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False
    )
    provider_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False
    )
    amount: Mapped[float] = mapped_column(
        Numeric(18, 4), nullable=False
    )
    currency: Mapped[str] = mapped_column(
        Enum("CNY", "USD", "USDC", name="currency_enum"), nullable=False
    )
    commission_rate: Mapped[float] = mapped_column(
        Numeric(5, 4), nullable=False, default=0.03
    )
    commission_amount: Mapped[float | None] = mapped_column(
        Numeric(18, 4), nullable=True
    )
    provider_payout: Mapped[float | None] = mapped_column(
        Numeric(18, 4), nullable=True
    )
    settlement_channel: Mapped[str] = mapped_column(
        Enum("fiat", "x402", "acp", name="settlement_channel_enum"),
        nullable=False,
    )
    escrow_status: Mapped[str] = mapped_column(
        Enum(
            "frozen",
            "partial_release",
            "released",
            "refunded",
            "disputed",
            name="escrow_status_enum",
        ),
        nullable=False,
        default="frozen",
    )
    escrow_frozen_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    escrow_released_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    authorization_level: Mapped[str | None] = mapped_column(
        Enum("L0", "L1", "L2", "L3", name="authority_level_enum"),
        nullable=True,
    )
    authorization_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), nullable=True
    )
    authorized_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    authorized_by: Mapped[str | None] = mapped_column(
        String(255), nullable=True
    )
    effect_score: Mapped[int | None] = mapped_column(
        nullable=True
    )
    effect_reported_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    status: Mapped[str] = mapped_column(
        Enum(
            "pending",
            "authorized",
            "processing",
            "completed",
            "failed",
            "cancelled",
            "disputed",
            name="transaction_status_enum",
        ),
        nullable=False,
        default="pending",
    )
    failure_reason: Mapped[str | None] = mapped_column(
        String(1024), nullable=True
    )
    external_settlement_id: Mapped[str | None] = mapped_column(
        String(255), nullable=True
    )
    settlement_confirmed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    __table_args__ = (
        Index("ix_payment_transactions_order_id", "order_id"),
        Index("ix_payment_transactions_agent_id", "agent_id"),
        Index("ix_payment_transactions_provider_id", "provider_id"),
        Index("ix_payment_transactions_status", "status"),
        Index("ix_payment_transactions_escrow_status", "escrow_status"),
        CheckConstraint(
            "effect_score IS NULL OR (effect_score >= 0 AND effect_score <= 5)",
            name="ck_payment_transaction_effect_score_range",
        ),
    )

    pool: Mapped[BudgetPool] = relationship(
        "BudgetPool", back_populates="transactions"
    )
    authorization_requests: Mapped[list[AuthorizationRequest]] = relationship(
        "AuthorizationRequest", back_populates="transaction", lazy="noload"
    )


class AuthorizationRequest(Base):
    __tablename__ = "authorization_requests"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    transaction_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("payment_transactions.id", ondelete="CASCADE"),
        nullable=False,
    )
    agent_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False
    )
    owner_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False
    )
    level: Mapped[str] = mapped_column(
        Enum("L2", "L3", name="auth_request_level_enum"),
        nullable=False,
    )
    amount: Mapped[float] = mapped_column(Numeric(18, 4), nullable=False)
    item_name: Mapped[str | None] = mapped_column(
        String(255), nullable=True
    )
    item_type: Mapped[str | None] = mapped_column(
        String(100), nullable=True
    )
    status: Mapped[str] = mapped_column(
        Enum(
            "pending",
            "approved",
            "rejected",
            "expired",
            name="auth_request_status_enum",
        ),
        nullable=False,
        default="pending",
    )
    notification_sent_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    notification_channel: Mapped[str] = mapped_column(
        Enum("email", "sms", "webhook", "in_app", name="notification_channel_enum"),
        nullable=False,
    )
    decided_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    decided_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), nullable=True
    )
    reject_reason: Mapped[str | None] = mapped_column(
        String(1024), nullable=True
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=datetime.utcnow
    )

    __table_args__ = (
        Index("ix_auth_requests_owner_status", "owner_id", "status"),
        Index("ix_auth_requests_expires_at", "expires_at"),
    )

    transaction: Mapped[PaymentTransaction] = relationship(
        "PaymentTransaction", back_populates="authorization_requests"
    )


class DailyBudgetSnapshot(Base):
    __tablename__ = "daily_budget_snapshots"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    pool_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("budget_pools.id", ondelete="CASCADE"),
        nullable=False,
    )
    agent_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), nullable=True
    )
    snapshot_date: Mapped[date] = mapped_column(Date, nullable=False)
    daily_spent: Mapped[float] = mapped_column(
        Numeric(18, 4), nullable=False, default=0
    )
    transaction_count: Mapped[int] = mapped_column(
        nullable=False, default=0
    )

    __table_args__ = (
        UniqueConstraint(
            "pool_id", "agent_id", "snapshot_date",
            name="uq_pool_agent_snapshot_date",
        ),
    )

    pool: Mapped[BudgetPool] = relationship(
        "BudgetPool", back_populates="snapshots"
    )
