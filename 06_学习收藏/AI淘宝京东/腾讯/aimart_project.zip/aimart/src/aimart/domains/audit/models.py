from __future__ import annotations

AUDIT_LOG_TABLE_DDL = """
CREATE TABLE IF NOT EXISTS audit_log
(
    log_id                  String,
    log_type                String,
    timestamp               DateTime,
    trace_id                String,
    span_id                 String,
    previous_hash           String,
    current_hash            String,
    actor_type              String,
    actor_id                String,
    session_id              Nullable(String),
    action_operation        String,
    action_target_type      Nullable(String),
    action_target_id        Nullable(String),
    action_result           String,
    action_error_code       Nullable(String),
    action_error_message    Nullable(String),
    data_hash               String,
    data                    String,
    context_ip_hash         Nullable(String)
)
ENGINE = MergeTree()
ORDER BY (timestamp, log_id)
"""
