from __future__ import annotations

import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    DateTime,
    Enum,
    Float,
    Index,
    Text,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from aimart.db.base import Base


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class TargetType(str, enum.Enum):
    ITEM = "item"
    PROVIDER = "provider"
    AGENT = "agent"


class TrustEventType(str, enum.Enum):
    PURCHASE = "purchase"
    EFFECT_REPORT = "effect_report"
    CERTIFICATION = "certification"
    COMPLAINT = "complaint"
    DISPUTE = "dispute"


class CertificationStatusEnum(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class TrustEvent(Base):
    """An event that influences the trust score of a target entity.

    Targets can be items, providers, or agents. Each event carries
    a score_delta that reflects its impact on the trust score.
    """

    __tablename__ = "trust_events"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    target_type: Mapped[TargetType] = mapped_column(
        Enum(TargetType, name="trust_target_type"), nullable=False
    )
    target_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False
    )
    event_type: Mapped[TrustEventType] = mapped_column(
        Enum(TrustEventType, name="trust_event_type"), nullable=False
    )
    event_data: Mapped[dict] = mapped_column(JSONB, nullable=False)
    score_delta: Mapped[float] = mapped_column(
        Float, nullable=False, default=0.0
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    __table_args__ = (
        Index("ix_trust_events_target", "target_type", "target_id"),
        Index("ix_trust_events_event_type", "event_type"),
    )


class Certification(Base):
    """A certification record issued by a certifier for a catalog item.

    Tracks the benchmark results, verification status, and expiration.
    """

    __tablename__ = "certifications"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    item_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False, index=True
    )
    certifier_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False, index=True
    )
    status: Mapped[CertificationStatusEnum] = mapped_column(
        Enum(CertificationStatusEnum, name="certification_status_enum"),
        nullable=False,
        default=CertificationStatusEnum.PENDING,
    )
    benchmark_results: Mapped[dict] = mapped_column(JSONB, nullable=False)
    verified_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )

    __table_args__ = (
        Index("ix_certifications_item_id", "item_id"),
        Index("ix_certifications_certifier_id", "certifier_id"),
    )
