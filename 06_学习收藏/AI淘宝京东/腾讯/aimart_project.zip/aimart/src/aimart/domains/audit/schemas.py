from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class AuditLogQuery(BaseModel):
    """Query parameters for audit log retrieval."""

    log_type: Optional[str] = None
    actor_id: Optional[str] = None
    target_id: Optional[str] = None
    action: Optional[str] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    page: int = Field(default=1, ge=1)
    size: int = Field(default=50, ge=1, le=200)


class AuditLogEntry(BaseModel):
    """Single audit log entry matching the ClickHouse table schema."""

    log_id: str
    log_type: str
    timestamp: datetime
    trace_id: str
    span_id: str
    previous_hash: str
    current_hash: str
    actor_type: str
    actor_id: str
    session_id: Optional[str] = None
    action_operation: str
    action_target_type: Optional[str] = None
    action_target_id: Optional[str] = None
    action_result: str
    action_error_code: Optional[str] = None
    action_error_message: Optional[str] = None
    data_hash: str
    data: str
    context_ip_hash: Optional[str] = None


class AuditLogResponse(BaseModel):
    """Paginated response for audit log queries."""

    entries: list[AuditLogEntry]
    total: int
    page: int
    size: int


class HashChainVerification(BaseModel):
    """Result of hash chain verification."""

    valid: bool
    message: str
    merkle_root: str
