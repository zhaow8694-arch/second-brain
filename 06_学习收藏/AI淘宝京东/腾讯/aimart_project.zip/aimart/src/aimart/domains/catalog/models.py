from __future__ import annotations

import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    DateTime,
    Enum,
    Float,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from aimart.db.base import Base


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class ItemType(str, enum.Enum):
    MODEL = "model"
    SKILL = "skill"
    EXPERT = "expert"
    COMPUTE = "compute"


class CatalogItemStatus(str, enum.Enum):
    PENDING = "pending"
    ACTIVE = "active"
    DELISTED = "delisted"
    SUSPENDED = "suspended"


class CertificationStatus(str, enum.Enum):
    NONE = "none"
    PENDING = "pending"
    CERTIFIED = "certified"
    REJECTED = "rejected"


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class CatalogItem(Base):
    """A capability offering listed on the AIMart marketplace.

    Each item is backed by a full AgentCard JSON document that describes
    identity, capabilities, performance benchmarks, pricing, delivery
    mechanism, and trust metadata.
    """

    __tablename__ = "catalog_items"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    provider_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), nullable=False, index=True
    )
    item_type: Mapped[ItemType] = mapped_column(
        Enum(ItemType, name="catalog_item_type"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    version: Mapped[str] = mapped_column(String(64), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    agentcard: Mapped[dict] = mapped_column(JSONB, nullable=False)
    agentcard_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    status: Mapped[CatalogItemStatus] = mapped_column(
        Enum(CatalogItemStatus, name="catalog_item_status"),
        nullable=False,
        default=CatalogItemStatus.PENDING,
    )
    certification_status: Mapped[CertificationStatus] = mapped_column(
        Enum(CertificationStatus, name="certification_status"),
        nullable=False,
        default=CertificationStatus.NONE,
    )
    trust_score: Mapped[float] = mapped_column(
        Float, nullable=False, default=50.0
    )
    total_transactions: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    total_revenue: Mapped[float] = mapped_column(
        Numeric(18, 4), nullable=False, default=0
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=datetime.utcnow,
    )

    __table_args__ = (
        Index("ix_catalog_items_provider_id", "provider_id"),
        Index("ix_catalog_items_item_type", "item_type"),
        Index("ix_catalog_items_status", "status"),
    )
