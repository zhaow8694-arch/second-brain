"""AIMart domain modules."""
