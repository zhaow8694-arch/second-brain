from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, Field, ConfigDict


# ---------------------------------------------------------------------------
# Order
# ---------------------------------------------------------------------------

class OrderCreateRequest(BaseModel):
    """Request body for creating a new order."""

    item_id: UUID
    quantity: int = Field(default=1, ge=1)
    budget_pool_id: UUID
    settlement_channel: str = Field(
        default="fiat", pattern="^(fiat|x402|acp)$"
    )


class OrderResponse(BaseModel):
    """Full representation of a marketplace order."""

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    agent_id: UUID
    item_id: UUID
    provider_id: UUID
    item_type: str
    item_name: str
    pricing_model: str
    amount: Decimal
    currency: str
    quantity: int
    status: str
    payment_transaction_id: Optional[UUID] = None
    trial_id: Optional[UUID] = None
    delivered_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    cancelled_at: Optional[datetime] = None
    cancel_reason: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class OrderListResponse(BaseModel):
    """Paginated list of orders."""

    items: list[OrderResponse]
    total: int
    page: int
    size: int


# ---------------------------------------------------------------------------
# Trial
# ---------------------------------------------------------------------------

class TrialCreateRequest(BaseModel):
    """Request body for creating a sandbox trial."""

    item_id: UUID
    input_data: dict


class TrialResponse(BaseModel):
    """Full representation of a sandbox trial."""

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    agent_id: UUID
    item_id: UUID
    status: str
    input_data: dict
    output_data: Optional[dict] = None
    performance_data: Optional[dict] = None
    sandbox_config: dict
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_at: datetime
