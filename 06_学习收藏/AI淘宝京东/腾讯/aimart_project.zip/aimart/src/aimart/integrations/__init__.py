"""AIMart LangChain integration plugin."""
