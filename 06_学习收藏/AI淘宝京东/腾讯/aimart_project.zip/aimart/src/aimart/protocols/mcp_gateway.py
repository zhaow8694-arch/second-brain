"""MCP (Model Context Protocol) gateway for AIMart.

Exposes AIMart capabilities as MCP tools so that any MCP-compatible AI agent
can discover, search, trial and purchase capabilities through the standard
MCP tool-calling interface.  Streaming responses are delivered via Server-Sent
Events (SSE).
"""

from __future__ import annotations

import json
from typing import Any, AsyncGenerator

import structlog

logger = structlog.get_logger()

# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------

AIMART_TOOLS: list[dict[str, Any]] = [
    {
        "name": "aimart_search",
        "description": (
            "Search the AIMart capability marketplace for AI models, skills, "
            "experts, or compute resources that match a given need.  Returns a "
            "ranked list of matching capabilities with pricing and trust scores."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "need_type": {
                    "type": "string",
                    "enum": ["model", "skill", "expert", "compute"],
                    "description": "The type of capability needed.",
                },
                "domains": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Domain tags to filter by (e.g. ['legal', 'nlp']).",
                },
                "task_description": {
                    "type": "string",
                    "description": "Free-text description of the task the capability should accomplish.",
                },
                "max_price": {
                    "type": "number",
                    "description": "Maximum acceptable price per call/token/hour.",
                },
                "min_trust_score": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 100,
                    "description": "Minimum trust score (0-100) for returned results.",
                },
            },
            "required": ["need_type", "domains"],
        },
    },
    {
        "name": "aimart_purchase",
        "description": (
            "Purchase a capability from the AIMart marketplace.  The caller "
            "must provide the item ID, a budget pool, and a settlement channel."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the capability item to purchase.",
                },
                "budget_pool_id": {
                    "type": "string",
                    "description": "UUID of the budget pool to charge.",
                },
                "settlement_channel": {
                    "type": "string",
                    "enum": ["fiat", "x402"],
                    "description": "Settlement channel for the transaction.",
                    "default": "fiat",
                },
                "quantity": {
                    "type": "integer",
                    "description": "Number of units (default 1).",
                    "default": 1,
                },
            },
            "required": ["item_id", "budget_pool_id"],
        },
    },
    {
        "name": "aimart_trial",
        "description": (
            "Request a trial run of a capability inside the AIMart sandbox.  "
            "The trial is rate-limited and sandboxed; results are returned as "
            "structured data for the agent to evaluate before purchasing."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "item_id": {
                    "type": "string",
                    "description": "UUID of the capability item to trial.",
                },
                "input_payload": {
                    "type": "object",
                    "description": "The input data to feed to the capability during the trial.",
                },
                "trial_config": {
                    "type": "object",
                    "properties": {
                        "max_tokens": {"type": "integer"},
                        "timeout_seconds": {"type": "integer", "default": 30},
                    },
                    "description": "Optional trial configuration.",
                },
            },
            "required": ["item_id", "input_payload"],
        },
    },
]


# ---------------------------------------------------------------------------
# Service dispatch helpers (thin wrappers over internal HTTP APIs)
# ---------------------------------------------------------------------------

async def _dispatch_search(arguments: dict[str, Any]) -> dict[str, Any]:
    """Call the internal search service."""
    # In production this would httpx-post to the search micro-service.
    # For now we return a placeholder so the gateway is testable end-to-end.
    logger.info("mcp.dispatch_search", arguments=arguments)
    return {
        "matches": [],
        "total": 0,
        "query": arguments,
    }


async def _dispatch_purchase(arguments: dict[str, Any]) -> dict[str, Any]:
    """Call the internal exchange/order service."""
    logger.info("mcp.dispatch_purchase", arguments=arguments)
    return {
        "order_id": "placeholder",
        "status": "pending",
        "item_id": arguments.get("item_id"),
    }


async def _dispatch_trial(arguments: dict[str, Any]) -> dict[str, Any]:
    """Call the internal sandbox/trial service."""
    logger.info("mcp.dispatch_trial", arguments=arguments)
    return {
        "trial_id": "placeholder",
        "status": "completed",
        "output": {},
    }


_DISPATCH_TABLE: dict[str, Any] = {
    "aimart_search": _dispatch_search,
    "aimart_purchase": _dispatch_purchase,
    "aimart_trial": _dispatch_trial,
}


# ---------------------------------------------------------------------------
# MCP Gateway
# ---------------------------------------------------------------------------

class MCPGateway:
    """Model Context Protocol gateway for AIMart.

    Translates MCP tool-list and tool-call requests into AIMart domain
    operations and streams responses back via SSE.
    """

    def __init__(self, base_url: str = "http://localhost:8080") -> None:
        self.base_url = base_url

    # -- Tool listing --------------------------------------------------------

    async def handle_tool_list(self, request: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Return the list of AIMart tools in MCP tool schema format.

        Parameters
        ----------
        request:
            The incoming MCP request payload (currently unused, reserved for
            future capability filtering).
        """
        logger.info("mcp.tool_list")
        return AIMART_TOOLS

    # -- Tool execution ------------------------------------------------------

    async def handle_tool_call(
        self,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> dict[str, Any]:
        """Dispatch an MCP tool call to the appropriate AIMart service.

        Parameters
        ----------
        tool_name:
            One of ``aimart_search``, ``aimart_purchase``, ``aimart_trial``.
        arguments:
            The tool arguments as validated against the tool's ``inputSchema``.
        """
        handler = _DISPATCH_TABLE.get(tool_name)
        if handler is None:
            logger.error("mcp.unknown_tool", tool_name=tool_name)
            return {"error": f"Unknown tool: {tool_name}"}

        logger.info("mcp.tool_call", tool_name=tool_name)
        result = await handler(arguments)
        return result

    # -- SSE streaming -------------------------------------------------------

    async def stream_tool_call(
        self,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> AsyncGenerator[str, None]:
        """Yield SSE-formatted events for a tool call.

        This is the primary entry-point for the SSE endpoint exposed by
        the FastAPI router.
        """
        result = await self.handle_tool_call(tool_name, arguments)
        # First event: the result payload
        yield f"data: {json.dumps({'type': 'result', 'tool': tool_name, 'data': result})}\n\n"
        # Final event: done marker
        yield "data: {\"type\": \"done\"}\n\n"
