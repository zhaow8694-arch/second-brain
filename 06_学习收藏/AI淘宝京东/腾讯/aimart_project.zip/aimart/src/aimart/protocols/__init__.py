"""AIMart protocol adapters package."""
