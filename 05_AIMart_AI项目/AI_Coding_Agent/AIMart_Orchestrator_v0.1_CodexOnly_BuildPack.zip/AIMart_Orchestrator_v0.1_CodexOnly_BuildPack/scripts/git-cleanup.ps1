param(
  [switch]$DeleteMerged
)
$ErrorActionPreference = "Stop"
$RootDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $RootDir
Write-Host "[git-cleanup] checking git repository"

try {
  git rev-parse --is-inside-work-tree | Out-Null
} catch {
  Write-Host "[git-cleanup] not a git repo; skipping"
  exit 0
}

git status --short

# Safe cleanup of ignored files only.
git clean -fdX

if ($DeleteMerged) {
  $CurrentBranch = git branch --show-current
  git branch --merged | ForEach-Object { $_.Trim().TrimStart('*').Trim() } | Where-Object {
    $_ -and $_ -notin @("main", "master", "develop", $CurrentBranch)
  } | ForEach-Object {
    git branch -d $_
  }
} else {
  Write-Host "[git-cleanup] merged branch deletion skipped. Use -DeleteMerged only after approval."
}

Write-Host "[git-cleanup] done"
