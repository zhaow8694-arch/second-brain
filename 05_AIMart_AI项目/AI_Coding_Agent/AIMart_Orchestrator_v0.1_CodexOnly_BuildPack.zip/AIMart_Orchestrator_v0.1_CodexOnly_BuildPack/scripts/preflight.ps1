$ErrorActionPreference = "Stop"
$RootDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $RootDir
Write-Host "[preflight] root: $RootDir"

function Test-Command($Name) {
  if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
    Write-Host "[preflight] missing command: $Name"
    return $false
  }
  return $true
}

Test-Command git | Out-Null
Test-Command node | Out-Null
Test-Command pnpm | Out-Null

if (Test-Path "package.json") {
  Write-Host "[preflight] package.json found"
} else {
  Write-Host "[preflight] package.json not found yet; this is expected before scaffold"
}

Write-Host "[preflight] done"
