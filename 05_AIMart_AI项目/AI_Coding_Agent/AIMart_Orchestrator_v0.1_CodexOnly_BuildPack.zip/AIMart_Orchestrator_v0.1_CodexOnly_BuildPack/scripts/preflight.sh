#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

echo "[preflight] root: $ROOT_DIR"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "[preflight] missing command: $1" >&2
    return 1
  fi
}

require_cmd git || true
require_cmd node || true
require_cmd pnpm || true

if [ -f package.json ]; then
  echo "[preflight] package.json found"
else
  echo "[preflight] package.json not found yet; this is expected before scaffold"
fi

echo "[preflight] done"
