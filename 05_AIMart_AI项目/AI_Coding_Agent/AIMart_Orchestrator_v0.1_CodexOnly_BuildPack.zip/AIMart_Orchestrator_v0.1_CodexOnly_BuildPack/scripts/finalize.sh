#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

echo "[finalize] AIMart Orchestrator v0.1 finalization started"

./scripts/preflight.sh
./scripts/backup.sh
./scripts/test.sh
./scripts/git-cleanup.sh
./scripts/tag-release.sh
./scripts/package.sh

cat > FINAL_DELIVERY_CHECK.md <<'EOF'
# Final Delivery Check

- [ ] Project runs locally
- [ ] Tests passed or failures documented
- [ ] Build passed or failures documented
- [ ] Backup generated
- [ ] Local Git tag created or skipped with reason
- [ ] Package artifact generated
- [ ] README/RUN_APP docs present
- [ ] No mixed-agent development used
EOF

cat > RELEASE_NOTES.md <<EOF
# Release Notes

Generated on: $(date)

## Scope

AIMart Orchestrator v0.1 Codex-only build.

## Notes

Remote tag push and production deployment are not performed by default.
EOF

echo "[finalize] done"
