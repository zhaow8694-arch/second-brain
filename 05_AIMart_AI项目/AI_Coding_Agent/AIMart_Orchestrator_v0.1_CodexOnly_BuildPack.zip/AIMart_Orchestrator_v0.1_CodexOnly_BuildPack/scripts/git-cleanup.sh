#!/usr/bin/env bash
set -euo pipefail

DELETE_MERGED=false
if [[ "${1:-}" == "--delete-merged" ]]; then
  DELETE_MERGED=true
fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

echo "[git-cleanup] checking git repository"
if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "[git-cleanup] not a git repo; skipping"
  exit 0
fi

git status --short

# Safe cleanup of ignored files only.
git clean -fdX

if $DELETE_MERGED; then
  CURRENT_BRANCH="$(git branch --show-current)"
  git branch --merged | sed 's/^..//' | grep -vE "^(main|master|develop|$CURRENT_BRANCH)$" | xargs -r git branch -d
else
  echo "[git-cleanup] merged branch deletion skipped. Use --delete-merged only after approval."
fi

echo "[git-cleanup] done"
