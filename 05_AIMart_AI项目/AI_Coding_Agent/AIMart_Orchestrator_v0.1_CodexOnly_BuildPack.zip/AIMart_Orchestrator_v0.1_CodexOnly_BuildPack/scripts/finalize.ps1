$ErrorActionPreference = "Stop"
$RootDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $RootDir

Write-Host "[finalize] AIMart Orchestrator v0.1 finalization started"

& .\scripts\preflight.ps1
& .\scripts\backup.ps1
& .\scripts\test.ps1
& .\scripts\git-cleanup.ps1
& .\scripts\tag-release.ps1
& .\scripts\package.ps1

@"
# Final Delivery Check

- [ ] Project runs locally
- [ ] Tests passed or failures documented
- [ ] Build passed or failures documented
- [ ] Backup generated
- [ ] Local Git tag created or skipped with reason
- [ ] Package artifact generated
- [ ] README/RUN_APP docs present
- [ ] No mixed-agent development used
"@ | Set-Content -Encoding UTF8 FINAL_DELIVERY_CHECK.md

@"
# Release Notes

Generated on: $(Get-Date)

## Scope

AIMart Orchestrator v0.1 Codex-only build.

## Notes

Remote tag push and production deployment are not performed by default.
"@ | Set-Content -Encoding UTF8 RELEASE_NOTES.md

Write-Host "[finalize] done"
